let accounts = [];
let transactions = [];
let charts = [];
let stock = [];
let shiftReport = {};

// ===== Accounts =====
function addAccount() {
  const name = document.getElementById("accountName").value;
  const type = document.getElementById("accountType").value;
  if (!name) return alert("Enter account name");
  accounts.push({ name, type });
  updateAccountUI();
  document.getElementById("accountName").value = "";
}

function updateAccountUI() {
  const list = document.getElementById("accountsList");
  list.innerHTML = "";
  const debitSelect = document.getElementById("debitAccount");
  const creditSelect = document.getElementById("creditAccount");
  debitSelect.innerHTML = "";
  creditSelect.innerHTML = "";

  accounts.forEach(acc => {
    const li = document.createElement("li");
    li.textContent = `${acc.name} (${acc.type})`;
    list.appendChild(li);

    [debitSelect, creditSelect].forEach(sel => {
      const option = document.createElement("option");
      option.value = acc.name;
      option.textContent = acc.name;
      sel.appendChild(option);
    });
  });
}

// ===== Transactions =====
function addTransaction(date, desc, debit, credit, amount) {
  if (!date || !desc || !debit || !credit || !amount) return alert("Fill all fields");
  transactions.push({ date, desc, debit, credit, amount });
  updateTransactionUI();
}

function addTransactionWrapper() {
  const date = document.getElementById("transactionDate").value;
  const desc = document.getElementById("transactionDesc").value;
  const debit = document.getElementById("debitAccount").value;
  const credit = document.getElementById("creditAccount").value;
  const amount = parseFloat(document.getElementById("transactionAmount").value);
  addTransaction(date, desc, debit, credit, amount ? amount : 0);
  document.getElementById("transactionDate").value = "";
  document.getElementById("transactionDesc").value = "";
  document.getElementById("transactionAmount").value = "";
}

function resetTransactions() {
  if(confirm("Are you sure you want to reset all transactions?")) {
    transactions = [];
    updateTransactionUI();
    document.getElementById("chartsContainer").innerHTML = "";
    charts = [];
  }
}

// ===== Excel Import =====
function importExcel() {
  const file = document.getElementById("excelFile").files[0];
  if (!file) return alert("Select an Excel file first");

  const reader = new FileReader();
  reader.onload = function(e) {
    const data = new Uint8Array(e.target.result);
    const workbook = XLSX.read(data, { type: 'array' });

    workbook.SheetNames.forEach(sheetName => {
      const sheet = workbook.Sheets[sheetName];
      const rows = XLSX.utils.sheet_to_json(sheet);

      if(sheetName.toLowerCase() === "transactions") {
        rows.forEach(row => {
          if(!accounts.find(a => a.name === row['Debit Account']) || !accounts.find(a => a.name === row['Credit Account'])) {
            console.warn(`Skipping transaction. Account missing: ${row['Description']}`);
            return;
          }
          addTransaction(row['Date'], row['Description'], row['Debit Account'], row['Credit Account'], row['Amount']);
        });
      }
    });
    alert("Excel imported successfully!");
  };
  reader.readAsArrayBuffer(file);
}

// ===== UI Updates =====
function updateTransactionUI() {
  const list = document.getElementById("transactionList");
  list.innerHTML = "";
  transactions.forEach(tx => {
    const li = document.createElement("li");
    li.textContent = `${tx.date} | ${tx.desc} | Debit: ${tx.debit} | Credit: ${tx.credit} | K${tx.amount}`;
    list.appendChild(li);
  });
  updateCharts();
}

// ===== Charts & Reports =====
function updateCharts() {
  const chartsContainer = document.getElementById("chartsContainer");
  chartsContainer.innerHTML = "";
  charts = [];

  const grouped = {};
  transactions.forEach(tx => {
    if(!grouped[tx.date]) grouped[tx.date] = [];
    grouped[tx.date].push(tx);
  });

  Object.keys(grouped).sort().forEach(date => {
    const dayTxs = grouped[date];
    const labels = dayTxs.map(tx => tx.desc);
    const data = dayTxs.map(tx => tx.amount);
    const colors = labels.map(() => `hsl(${Math.random()*360},70%,60%)`);

    // Pie chart
    const pieCard = document.createElement("div");
    pieCard.className = "chartCard";
    const pieTitle = document.createElement("h4");
    pieTitle.textContent = `Transactions Pie - ${date}`;
    pieCard.appendChild(pieTitle);

    const pieCanvas = document.createElement("canvas");
    pieCard.appendChild(pieCanvas);

    const pieBtn = document.createElement("button");
    pieBtn.textContent = "Download Pie Chart";
    pieBtn.className = "downloadBtn";
    pieBtn.onclick = () => downloadChart(pieCanvas, `PieChart-${date}`);
    pieCard.appendChild(pieBtn);

    chartsContainer.appendChild(pieCard);

    const pieChart = new Chart(pieCanvas.getContext("2d"), {
      type: "pie",
      data: { labels, datasets: [{ data, backgroundColor: colors }] },
      options: {
        plugins: {
          legend: { position: 'bottom' },
          tooltip: {
            callbacks: {
              label: function(context) {
                const total = context.dataset.data.reduce((a,b)=>a+b,0);
                const percent = ((context.raw/total)*100).toFixed(2);
                return `${context.label}: K${context.raw} (${percent}%)`;
              }
            }
          },
          datalabels: {
            formatter: (value, ctx) => {
              const total = ctx.chart.data.datasets[0].data.reduce((a,b)=>a+b,0);
              return ((value/total)*100).toFixed(1)+'%';
            },
            color: '#fff',
            font: { weight: 'bold', size: 12 }
          }
        }
      },
      plugins: [ChartDataLabels]
    });
    charts.push(pieChart);
  });
}

// ===== Download Functions =====
function downloadChart(canvas, filename) {
  const link = document.createElement('a');
  link.download = filename + '.png';
  link.href = canvas.toDataURL('image/png', 1);
  link.click();
}

function downloadAllCharts() {
  charts.forEach((chart, idx) => {
    downloadChart(chart.canvas, `Chart-${idx+1}`);
  });
}

function downloadChartsPDF() {
  const { jsPDF } = window.jspdf;
  const pdf = new jsPDF('p', 'mm', 'a4');
  let yOffset = 10;
  const pageWidth = pdf.internal.pageSize.getWidth();
  const pageHeight = pdf.internal.pageSize.getHeight();

  charts.forEach((chart, idx) => {
    const imgData = chart.toBase64Image();
    const imgProps = pdf.getImageProperties(imgData);
    const pdfWidth = pageWidth - 20;
    const pdfHeight = (imgProps.height * pdfWidth) / imgProps.width;

    if (yOffset + pdfHeight > pageHeight) {
      pdf.addPage();
      yOffset = 10;
    }
    pdf.addImage(imgData, 'PNG', 10, yOffset, pdfWidth, pdfHeight);
    yOffset += pdfHeight + 10;
  });

  pdf.save('AllCharts.pdf');
}

// ===== Stock Take =====
function showStockTake() {
  document.getElementById("accountsSection").style.display = "none";
  document.getElementById("transactionSection").style.display = "none";
  document.getElementById("chartsSection").style.display = "none";
  document.getElementById("stockTakeSection").style.display = "block";
}

function showMainPage() {
  document.getElementById("accountsSection").style.display = "block";
  document.getElementById("transactionSection").style.display = "block";
  document.getElementById("chartsSection").style.display = "block";
  document.getElementById("stockTakeSection").style.display = "none";
}

function addStockItem() {
  const name = document.getElementById("itemName").value;
  const qty = parseInt(document.getElementById("itemQty").value);
  const price = parseFloat(document.getElementById("itemPrice").value);

  if (!name || !qty || !price) return alert("Fill all fields");
  stock.push({ name, qty, price });
  updateStockUI();

  document.getElementById("itemName").value = "";
  document.getElementById("itemQty").value = "";
  document.getElementById("itemPrice").value = "";
}

function resetStock() {
  if(confirm("Are you sure you want to reset stock?")) {
    stock = [];
    updateStockUI();
  }
}

function updateStockUI() {
  const list = document.getElementById("stockList");
  const summary = document.getElementById("stockSummary");
  const report = document.getElementById("stockReport");
  list.innerHTML = "";
  summary.innerHTML = "";
  report.innerHTML = "";

  let totalValue = 0;
  stock.forEach(item => {
    const li = document.createElement("li");
    li.textContent = `${item.name} | Qty: ${item.qty} | Unit Price: K${item.price} | Total: K${item.qty * item.price}`;
    list.appendChild(li);
    totalValue += item.qty * item.price;
  });

  summary.innerHTML = `<h3>Stock Summary</h3>
    Total Items: ${stock.length}<br>
    Total Value: K${totalValue}`;

  // Stock Take Report with working-out
  let reportHtml = "<h3>Stock Take Report</h3><strong>Working Out:</strong><br>";
  stock.forEach(item => {
    reportHtml += `- ${item.name}: ${item.qty} × K${item.price} = K${item.qty * item.price}<br>`;
  });
  reportHtml += `<br><strong>Total Stock Value = K${totalValue}</strong>`;
  report.innerHTML = reportHtml;
}

// ===== End-of-Shift Cash Reconciliation =====
function generateShiftReport() {
  const date = document.getElementById("shiftDate").value;
  const shiftTime = document.getElementById("shiftTime").value;
  const employee = document.getElementById("employeeName").value;
  const openingCash = parseFloat(document.getElementById("openingCash").value) || 0;
  const sales = parseFloat(document.getElementById("cashSales").value) || 0;
  const payments = parseFloat(document.getElementById("cashPayments").value) || 0;
  const actualCash = parseFloat(document.getElementById("actualCash").value) || 0;

  const expectedCash = openingCash + sales - payments;
  const variance = expectedCash - actualCash;

  let html = `<h3>End-of-Shift Cash Reconciliation</h3>
  <strong>Date:</strong> ${date}<br>
  <strong>Shift:</strong> ${shiftTime}<br>
  <strong>Employee:</strong> ${employee}<br><br>

  <strong>Opening Cash (Float):</strong> K${openingCash}<br>
  <strong>Total Cash Receipts/Sales:</strong> K${sales}<br>
  <strong>Total Cash Disbursements/Payments:</strong> K${payments}<br>
  <strong>Expected Cash on Hand:</strong> K${expectedCash}<br>
  <strong>Actual Cash on Hand:</strong> K${actualCash}<br>
  <strong>Variance:</strong> K${variance}<br>
  <strong>Notes/Comments:</strong> ____________________________<br>`;

  document.getElementById("shiftReportContainer").innerHTML = html;

  // Save data for PDF/Word download
  shiftReport = {date, shiftTime, employee, openingCash, sales, payments, actualCash, expectedCash, variance};
}

function downloadShiftPDF() {
  if(!shiftReport.date) return alert("Generate the shift report first");
  const { jsPDF } = window.jspdf;
  const pdf = new jsPDF();
  let yOffset = 10;
  pdf.setFontSize(12);
  pdf.text("End-of-Shift Cash Reconciliation", 10, yOffset);
  yOffset += 10;
  for (let key in shiftReport) {
    pdf.text(`${key}: K${shiftReport[key]}`, 10, yOffset);
    yOffset += 8;
  }
  pdf.save(`Shift-${shiftReport.date}.pdf`);
}

function downloadShiftWord() {
  if(!shiftReport.date) return alert("Generate the shift report first");
  let content = `<html><head><meta charset="utf-8"><title>Shift Report</title></head><body>`;
  content += `<h2>End-of-Shift Cash Reconciliation</h2>`;
  for (let key in shiftReport) {
    content += `<strong>${key}:</strong> K${shiftReport[key]}<br>`;
  }
  content += "</body></html>";
  const blob = new Blob([content], {type: "application/msword"});
  const link = document.createElement('a');
  link.href = URL.createObjectURL(blob);
  link.download = `Shift-${shiftReport.date}.doc`;
  link.click();
}
